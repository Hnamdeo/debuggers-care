<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
require __DIR__ . '/lib/ingest.php';
$u = require_login();
$msgs = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['pdf'])) {
    check_csrf();
    set_time_limit(600);
    $files = $_FILES['pdf'];
    foreach ((array)$files['name'] as $i => $name) {
        if ($files['error'][$i] !== UPLOAD_ERR_OK) { $msgs[] = ['err', "$name: upload failed"]; continue; }
        $head = (string)file_get_contents($files['tmp_name'][$i], false, null, 0, 5);
        if ($head !== '%PDF-') { $msgs[] = ['err', "$name is not a PDF"]; continue; }
        [$id, $dup] = store_document($files['tmp_name'][$i], $name, 'upload', null, $u['name']);
        if ($dup) { $msgs[] = ['warn', "$name was already received earlier (same file)."]; continue; }
        audit('upload', "document $id");
        $r = process_document($id);
        $msgs[] = $r['ok'] ? ['ok', "$name: {$r['records']} records saved."] : ['err', "$name: " . $r['error']];
    }
}
$docs = db()->query('SELECT * FROM documents ORDER BY received_at DESC, id DESC LIMIT 300')->fetchAll();
page_head('Documents', 'documents.php');
?>
<h1>Documents received</h1>
<?php foreach ($msgs as [$k, $m]): ?><div class="alert <?= $k ?>"><?= h($m) ?></div><?php endforeach; ?>
<div class="card">
  <h2>How PDFs arrive</h2>
  <p class="small">Thanas and the Jail Department send PDFs to the Crime Branch WhatsApp Business number as they do today. Each PDF is picked up automatically, read by AI and saved here within about a minute. The sender gets a WhatsApp reply with the number of records saved.</p>
  <form method="post" enctype="multipart/form-data" class="drop">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <p><b>Or add PDFs by hand</b> (for files received by email or pen drive)</p>
    <input type="file" name="pdf[]" accept="application/pdf" multiple required>
    <button class="btn sm">Read and save</button>
    <?php if ((string)cfg('anthropic.api_key') === ''): ?><p class="hint">Demo mode: the AI reader is switched off, so only the bundled sample PDFs can be read.</p><?php endif; ?>
  </form>
</div>
<div class="card tbl-wrap">
<table>
  <tr><th>Received</th><th>From</th><th>File</th><th>Type</th><th>Report date</th><th>Records</th><th>Status</th></tr>
  <?php foreach ($docs as $d): ?>
  <tr>
    <td class="small"><?= fmt_date($d['received_at']) ?></td>
    <td class="small"><?= source_icon($d['source']) ?><div><?= h($d['sender_name']) ?></div></td>
    <td><a href="document.php?id=<?= (int)$d['id'] ?>"><?= h($d['filename']) ?></a><div class="small muted"><?= h($d['title']) ?></div></td>
    <td class="small"><?= doc_type_label($d['doc_type']) ?><div class="muted"><?= h($d['district']) ?></div></td>
    <td class="small"><?= fmt_date($d['report_date']) ?></td>
    <td><b><?= (int)$d['record_count'] ?></b><?= $d['stated_count'] !== null ? '<span class="muted small"> / ' . (int)$d['stated_count'] . '</span>' : '' ?></td>
    <td><?= status_badge($d['status']) ?></td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php page_foot();
