<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
require __DIR__ . '/lib/ingest.php';
require __DIR__ . '/lib/search.php';
$u = require_login();
$id = (int)($_GET['id'] ?? 0);
$msg = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reread') {
    check_csrf();
    set_time_limit(600);
    audit('reread', "document $id");
    $r = process_document($id);
    $msg = $r['ok'] ? ['ok', "Read again: {$r['records']} records saved."] : ['err', $r['error']];
}
$d = get_document($id);
if (!$d) { http_response_code(404); exit('Not found'); }
audit('view_document', "document $id");
$recs = db()->prepare('SELECT * FROM records WHERE document_id=? ORDER BY id');
$recs->execute([$id]);
$recs = $recs->fetchAll();
$pc = db()->prepare('SELECT * FROM persons WHERE record_id=? ORDER BY id');
page_head($d['filename'], 'documents.php');
?>
<p><a href="documents.php">← All documents</a></p>
<h1><?= h($d['filename']) ?> <?= status_badge($d['status']) ?></h1>
<?php if ($msg): ?><div class="alert <?= $msg[0] ?>"><?= h($msg[1]) ?></div><?php endif; ?>
<?php if ($d['error']): ?><div class="alert <?= $d['status'] === 'error' ? 'err' : 'warn' ?>"><?= h($d['error']) ?></div><?php endif; ?>
<div class="grid2">
  <div class="card tbl-wrap">
    <h2><?= (int)$d['record_count'] ?> records read from this PDF</h2>
    <table>
      <tr><th>#</th><th>Thana</th><th>FIR / Section</th><th>People</th></tr>
      <?php foreach ($recs as $r): $pc->execute([$r['id']]); ?>
      <tr>
        <td><?= h($r['serial_no']) ?></td>
        <td><?= h($r['thana']) ?><div class="small muted"><?= fmt_date($r['event_date']) ?></div></td>
        <td><a href="record.php?id=<?= (int)$r['id'] ?>"><?= $r['fir_number'] ? '<b>' . h($r['fir_number']) . '</b>' : 'Open' ?></a><div class="small"><?= h($r['sections']) ?></div></td>
        <td class="small"><?php foreach ($pc->fetchAll() as $p): ?><div><span class="muted"><?= h(explode(' · ', role_label($p['role']))[0]) ?>:</span> <?= person_line($p) ?></div><?php endforeach; ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
  <div>
    <div class="card">
      <dl class="kv">
        <dt>Type</dt><dd><?= doc_type_label($d['doc_type']) ?></dd>
        <dt>Title</dt><dd><?= h($d['title']) ?: '—' ?></dd>
        <dt>District</dt><dd><?= h($d['district']) ?: '—' ?></dd>
        <dt>Report date</dt><dd><?= fmt_date($d['report_date']) ?></dd>
        <?php if ($d['period_from']): ?><dt>Period</dt><dd><?= fmt_date($d['period_from']) ?> to <?= fmt_date($d['period_to']) ?></dd><?php endif; ?>
        <dt>Count on PDF</dt><dd><?= $d['stated_count'] ?? '—' ?> · read: <?= (int)$d['record_count'] ?></dd>
        <dt>Received</dt><dd><?= source_icon($d['source']) ?> <?= h($d['sender_name']) ?> <?= h($d['sender_phone']) ?><br><?= fmt_date($d['received_at']) ?></dd>
        <dt>Read by</dt><dd class="small"><?= h($d['ai_model']) ?: '—' ?> · <?= fmt_date($d['processed_at']) ?></dd>
      </dl>
      <form method="post" style="margin-top:12px"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="action" value="reread">
        <a class="btn sec sm" href="file.php?id=<?= (int)$d['id'] ?>" target="_blank">Open PDF</a>
        <button class="btn sec sm">Read again</button></form>
    </div>
    <iframe class="pdf" src="file.php?id=<?= (int)$d['id'] ?>" title="Original PDF"></iframe>
  </div>
</div>
<?php page_foot();
