<?php
/**
 * WhatsApp Business Cloud API webhook.
 * In the Meta app: Webhooks > WhatsApp Business Account > Callback URL = https://<domain>/webhook.php,
 * Verify token = config whatsapp.verify_token, subscribe to "messages".
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/ingest.php';
require __DIR__ . '/lib/whatsapp.php';

// 1) Verification handshake
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $token = (string)cfg('whatsapp.verify_token');
    if ($token !== '' && ($_GET['hub_mode'] ?? '') === 'subscribe' && hash_equals($token, (string)($_GET['hub_verify_token'] ?? ''))) {
        echo $_GET['hub_challenge'] ?? '';
    } else {
        http_response_code(403);
    }
    exit;
}

// 2) Incoming messages
$raw = (string)file_get_contents('php://input');
if (!wa_signature_ok($raw)) {
    http_response_code(401);
    exit;
}
$payload = json_decode($raw, true) ?: [];
$allowed = cfg('whatsapp.allowed_senders', []);
$queued = [];

foreach ($payload['entry'] ?? [] as $entry) {
    foreach ($entry['changes'] ?? [] as $change) {
        $value = $change['value'] ?? [];
        $names = [];
        foreach ($value['contacts'] ?? [] as $c) {
            $names[$c['wa_id'] ?? ''] = $c['profile']['name'] ?? null;
        }
        foreach ($value['messages'] ?? [] as $m) {
            $from = (string)($m['from'] ?? '');
            if ($allowed && !isset($allowed[$from])) {
                continue; // not an authorised thana / jail number
            }
            if (($m['type'] ?? '') !== 'document' || !str_contains((string)($m['document']['mime_type'] ?? ''), 'pdf')) {
                continue; // only PDFs are read for now
            }
            try {
                $tmp = wa_download_media((string)$m['document']['id']);
                [$docId, $dup] = store_document($tmp, (string)($m['document']['filename'] ?? 'whatsapp.pdf'), 'whatsapp',
                    $from, $allowed[$from] ?? ($names[$from] ?? null), $m['id'] ?? null);
                if (!$dup) {
                    $queued[] = [$docId, $from];
                }
            } catch (Throwable $e) {
                error_log('Webhook: ' . $e->getMessage());
            }
        }
    }
}

// Answer Meta at once (it retries slow webhooks), then read the PDFs.
http_response_code(200);
echo 'OK';
if (function_exists('litespeed_finish_request')) {
    litespeed_finish_request();
} elseif (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
}
ignore_user_abort(true);
set_time_limit(600);
foreach ($queued as [$docId, $from]) {
    $res = process_document($docId);
    if (cfg('whatsapp.reply_to_sender')) {
        $d = $res['doc'];
        wa_send_text($from, $res['ok']
            ? "✅ Received \"{$d['filename']}\". {$d['record_count']} records saved to Crime Branch database."
            : "⚠️ Received \"{$d['filename']}\" but it could not be read automatically. Crime Branch will check it.");
    }
}
