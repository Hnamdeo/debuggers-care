<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
require __DIR__ . '/lib/search.php';
$u = require_login();

$f = [
    'q' => trim((string)($_GET['q'] ?? '')),
    'type' => (string)($_GET['type'] ?? ''),
    'thana' => (string)($_GET['thana'] ?? ''),
    'district' => (string)($_GET['district'] ?? ''),
    'section' => trim((string)($_GET['section'] ?? '')),
    'from' => (string)($_GET['from'] ?? ''),
    'to' => (string)($_GET['to'] ?? ''),
];
$searching = (bool)array_filter($f);
$tokens = query_tokens($f['q']);
$rows = $searching ? search_records($f) : search_records([], 15);
$people = $f['q'] !== '' ? search_people($f['q']) : [];
if ($searching) {
    audit('search', json_encode(array_filter($f), JSON_UNESCAPED_UNICODE));
}

$stats = db()->query("SELECT
    (SELECT COUNT(*) FROM documents) docs,
    (SELECT COUNT(*) FROM documents WHERE received_at LIKE '" . date('Y-m-d') . "%') docs_today,
    (SELECT COUNT(*) FROM records WHERE record_type='fir') firs,
    (SELECT COUNT(*) FROM records WHERE record_type='jail_release') jail,
    (SELECT COUNT(*) FROM persons) persons,
    (SELECT COUNT(*) FROM (SELECT person_key FROM persons WHERE person_key IS NOT NULL GROUP BY person_key HAVING COUNT(DISTINCT record_id) > 1) x) repeats")->fetch();
$thanas = distinct_values('thana');
$districts = distinct_values('district');

page_head('Search', 'index.php');
?>
<div class="tiles">
  <div class="tile"><div class="n"><?= (int)$stats['docs'] ?></div><div class="l">PDFs received<?= $stats['docs_today'] ? ' · ' . (int)$stats['docs_today'] . ' today' : '' ?></div></div>
  <div class="tile"><div class="n"><?= (int)$stats['firs'] ?></div><div class="l">FIRs (from DSRs)</div></div>
  <div class="tile"><div class="n"><?= (int)$stats['jail'] ?></div><div class="l">Jail releases</div></div>
  <div class="tile"><div class="n"><?= (int)$stats['persons'] ?></div><div class="l">People indexed</div></div>
  <div class="tile"><div class="n"><?= (int)$stats['repeats'] ?></div><div class="l"><a href="people.php">Names seen in 2+ records</a></div></div>
</div>

<form class="card" method="get">
  <div class="search">
    <input type="search" name="q" value="<?= h($f['q']) ?>" placeholder="Name, father's name, phone, FIR no, vehicle no, place… (Hindi or English)" autofocus>
    <button class="btn">Search</button>
    <?php if ($searching): ?><a class="btn sec" href="index.php">Clear</a><?php endif; ?>
  </div>
  <div class="filters">
    <select name="type"><option value="">All record types</option>
      <option value="fir" <?= $f['type'] === 'fir' ? 'selected' : '' ?>>FIRs (DSR)</option>
      <option value="jail_release" <?= $f['type'] === 'jail_release' ? 'selected' : '' ?>>Jail releases</option></select>
    <select name="district"><option value="">All districts</option><?php foreach ($districts as $d): ?><option <?= $f['district'] === $d ? 'selected' : '' ?>><?= h($d) ?></option><?php endforeach; ?></select>
    <select name="thana"><option value="">All thanas</option><?php foreach ($thanas as $t): ?><option <?= $f['thana'] === $t ? 'selected' : '' ?>><?= h($t) ?></option><?php endforeach; ?></select>
    <input name="section" value="<?= h($f['section']) ?>" placeholder="Section / Act e.g. 303 or आर्म्स" size="22">
    <label class="small muted">From <input type="date" name="from" value="<?= h($f['from']) ?>"></label>
    <label class="small muted">To <input type="date" name="to" value="<?= h($f['to']) ?>"></label>
  </div>
  <div class="hint">Try: <a href="?q=अनिल">अनिल</a> · <a href="?q=anil">anil</a> · <a href="?q=CG04">CG04</a> · <a href="?section=आर्म्स">Arms Act</a> · <a href="?type=jail_release">all jail releases</a></div>
</form>

<?php if ($people): ?>
<div class="card">
  <h2>People matching “<?= h($f['q']) ?>”</h2>
  <div class="chips">
  <?php foreach ($people as $p): ?>
    <a class="chip <?= $p['n'] > 1 ? 'repeat' : '' ?>" href="person.php?key=<?= urlencode($p['person_key']) ?>">
      <b><?= hl($p['name'] ?: $p['name_en'], $tokens) ?></b>
      <small><?= h($p['name_en']) ?><?= $p['father_name'] ? ' · c/o ' . h($p['father_name']) : '' ?></small><br>
      <small><?= (int)$p['n'] ?> record<?= $p['n'] > 1 ? 's' : '' ?> · <?= h(str_replace(['accused', 'released_prisoner', 'victim', 'complainant', 'deceased'], ['accused', 'released', 'victim', 'complainant', 'deceased'], $p['roles'])) ?></small>
    </a>
  <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <h2><?= $searching ? count($rows) . ' record' . (count($rows) === 1 ? '' : 's') . ' found' : 'Latest records' ?></h2>
  <?php if (!$rows): ?><p class="muted">Nothing matches. Try fewer words, or the English spelling.</p><?php else: ?>
  <div class="tbl-wrap"><table>
    <tr><th>Type</th><th>Date</th><th>Thana</th><th>FIR / Section</th><th>People</th><th>What happened</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><span class="badge t-<?= h($r['record_type']) ?>"><?= record_type_label($r['record_type']) ?></span></td>
      <td class="small"><?= fmt_date($r['event_date']) ?></td>
      <td><?= hl($r['thana'], $tokens) ?><div class="muted small"><?= h($r['district']) ?><?= $r['zone'] ? ' · ' . h($r['zone']) : '' ?></div></td>
      <td><?php if ($r['fir_number']): ?><a href="record.php?id=<?= (int)$r['id'] ?>"><b><?= hl($r['fir_number'], $tokens) ?></b></a> <?php endif; ?>
          <div class="small"><?= hl($r['sections'], $tokens) ?></div>
          <?php if ($r['crime_head']): ?><span class="badge"><?= h($r['crime_head']) ?></span><?php endif; ?></td>
      <td class="small"><?php foreach (array_slice($r['persons'], 0, 4) as $p): ?><div><span class="muted"><?= h(explode(' · ', role_label($p['role']))[0]) ?>:</span> <?= person_line($p, $tokens) ?></div><?php endforeach; ?>
          <?= count($r['persons']) > 4 ? '<div class="muted">+' . (count($r['persons']) - 4) . ' more</div>' : '' ?></td>
      <td class="small"><?= hl($r['summary_en'] ?: mb_strimwidth((string)$r['details'], 0, 140, '…'), $tokens) ?> <a href="record.php?id=<?= (int)$r['id'] ?>">Open</a></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <?php endif; ?>
</div>
<?php page_foot();
