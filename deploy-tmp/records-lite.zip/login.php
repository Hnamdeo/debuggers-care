<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
start_session();
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $user = trim((string)($_POST['username'] ?? ''));
    $acct = cfg('users', [])[$user] ?? null;
    // small delay against password guessing
    usleep(300000);
    if ($acct && password_verify((string)($_POST['password'] ?? ''), $acct['hash'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['username' => $user, 'name' => $acct['name'], 'role' => $acct['role']];
        audit('login');
        $next = (string)($_GET['next'] ?? 'index.php');
        header('Location: ' . (preg_match('#^/?[a-z_]+\.php#', ltrim($next, '/')) ? $next : 'index.php'));
        exit;
    }
    $err = 'Wrong username or password.';
    db()->prepare('INSERT INTO audit_log (at, username, action, detail, ip) VALUES (?,?,?,?,?)')
        ->execute([now(), $user, 'login_failed', null, $_SERVER['REMOTE_ADDR'] ?? '']);
}
page_head('Sign in');
?>
<div class="card login">
  <h1>Sign in</h1>
  <p class="muted small">Authorised officers only. Every search is recorded.</p>
  <?php if ($err): ?><div class="alert err"><?= h($err) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <label>Username<input name="username" autocomplete="username" required autofocus></label>
    <label>Password<input name="password" type="password" autocomplete="current-password" required></label>
    <button class="btn" style="width:100%">Sign in</button>
  </form>
</div>
<?php page_foot();
