# Police Records Intelligence (demo)

Reads police PDFs that arrive on a WhatsApp Business number (Daily Situation Reports, Jail Rihai lists),
extracts every row with AI into a database, and gives officers one search box for names, father's names,
phone numbers, FIR numbers, vehicle numbers, places and sections, in Hindi or English.

Designed and developed by Debuggers Space Solutions.

## How it works
1. Thana / jail sends a PDF to the Crime Branch WhatsApp Business number (Meta Cloud API).
2. `webhook.php` receives it, checks the sender is on the allowed list, downloads the PDF and stores it privately.
3. The PDF goes to Claude (`lib/extract.php`) with a fixed JSON schema. Claude reads the scanned/Kruti Dev/Unicode
   Hindi tables and returns one record per row, plus English transliteration of names for English search.
4. Records and people are saved (`records`, `persons` tables). If the count printed on the PDF ("28 प्रकरण") does not
   match the rows read, the document is flagged "Check" for a human.
5. The sender gets a WhatsApp reply: "Received, N records saved".
6. Officers search on `index.php`; the same name + father's name across PDFs is linked ("Repeat names").
   Every login, search and view is written to the audit log.

## Install on Hostinger (demo.debuggersspace.com/records)
1. Upload the zip into `public_html/<subdomain folder>/records/` and extract. PHP 8.1+ with pdo_sqlite, curl, mbstring.
2. Edit `config.php`: users (hash with `php cli/hash.php "password"`), Anthropic API key, WhatsApp settings.
3. `storage/` must be writable. `.htaccess` already blocks storage/, lib/, vendor/, config.php and sets noindex.
4. Optional cron (hPanel > Advanced > Cron Jobs), every 5 min: `php /home/<user>/public_html/.../records/cli/process.php`
5. For MySQL instead of SQLite set `db.driver = mysql` and fill `db.mysql`; tables are created automatically.

## WhatsApp setup (client side)
- Meta Business account (verified) + WhatsApp Business Platform app; add the Crime Branch number
  (if that number already runs the WhatsApp Business app, use Meta "coexistence" onboarding so the phone app keeps working).
- Webhook URL `https://<domain>/records/webhook.php`, verify token = `whatsapp.verify_token`, subscribe to `messages`.
- Permanent System User token -> `whatsapp.access_token`; App secret -> `whatsapp.app_secret`.
- Ordinary WhatsApp *groups* cannot be read by the official API. Thanas should send PDFs directly to the business
  number (or forward them from the group). Unofficial "WhatsApp Web bot" tools are not used: they break Meta's terms
  and can get the number banned.

## Demo data
`samples/` holds 17 synthetic PDFs (fake names) and their saved readings, so the demo works without an API key.
`php cli/seed_demo.php` loads them. Never put real police PDFs in a public demo or repository.
