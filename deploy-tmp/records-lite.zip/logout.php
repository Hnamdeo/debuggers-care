<?php
require __DIR__ . '/lib/bootstrap.php';
start_session();
if (current_user()) { audit('logout'); }
$_SESSION = [];
session_destroy();
header('Location: login.php');
