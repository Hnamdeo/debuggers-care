<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
require_login();
$rows = db()->query("SELECT person_key, MIN(name) name, MIN(name_en) name_en, MIN(father_name) father_name, COUNT(DISTINCT record_id) n,
        GROUP_CONCAT(DISTINCT role) roles
    FROM persons WHERE person_key IS NOT NULL GROUP BY person_key HAVING COUNT(DISTINCT record_id) > 1 ORDER BY n DESC, name LIMIT 300")->fetchAll();
page_head('Repeat names', 'people.php');
?>
<h1>Names that appear in more than one record</h1>
<p class="muted">Same name and father's name found in two or more PDFs, for example an accused in an FIR who was later released from jail. Useful for spotting repeat offenders.</p>
<div class="card">
<?php if (!$rows): ?><p class="muted">No repeats yet.</p><?php else: ?>
<table><tr><th>Name</th><th>Father / husband</th><th>Records</th><th>Seen as</th></tr>
<?php foreach ($rows as $p): ?>
<tr><td><a href="person.php?key=<?= urlencode($p['person_key']) ?>"><b><?= h($p['name']) ?></b></a> <span class="muted small"><?= h($p['name_en']) ?></span></td>
<td><?= h($p['father_name']) ?></td><td><b><?= (int)$p['n'] ?></b></td>
<td class="small"><?= h(str_replace('released_prisoner', 'released', $p['roles'])) ?></td></tr>
<?php endforeach; ?></table>
<?php endif; ?>
</div>
<?php page_foot();
