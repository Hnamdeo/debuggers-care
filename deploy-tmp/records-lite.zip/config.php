<?php
$c = require __DIR__ . '/config.sample.php';
$c['users'] = [
    'demo' => ['name' => 'Demo Officer', 'role' => 'admin', 'hash' => '$2y$10$uS.6tSURrUquxbtIkVBeaO.0Qs.zrYeMz.eDGjHryvzDhFfb4a3ie'],
];
// $c['anthropic']['api_key'] = 'sk-ant-...';   // switch on live AI reading
return $c;
