<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
require __DIR__ . '/lib/search.php';
require_login();
$key = (string)($_GET['key'] ?? '');
$st = db()->prepare('SELECT p.*, r.record_type, r.fir_number, r.thana, r.district, r.sections, r.event_date, r.crime_head, r.summary_en, r.release_date, r.jail_entry_date
    FROM persons p JOIN records r ON r.id=p.record_id WHERE p.person_key=? ORDER BY r.event_date, r.id');
$st->execute([$key]);
$rows = $st->fetchAll();
if (!$rows) { http_response_code(404); exit('Not found'); }
audit('view_person', $key);
$first = $rows[0];
$names = array_unique(array_filter(array_column($rows, 'name')));
$addresses = array_unique(array_filter(array_column($rows, 'address')));
$phones = array_unique(array_filter(array_column($rows, 'phone')));
$ages = array_filter(array_column($rows, 'age'));
page_head($first['name'] ?: $first['name_en']);
?>
<p><a href="javascript:history.back()">← Back</a></p>
<h1><?= h($first['name'] ?: $first['name_en']) ?> <span class="muted" style="font-weight:400"><?= h($first['name_en']) ?></span></h1>
<div class="grid2">
  <div class="card">
    <h2>Timeline · <?= count($rows) ?> record<?= count($rows) > 1 ? 's' : '' ?></h2>
    <table>
      <tr><th>Date</th><th>As</th><th>Record</th><th>Thana</th><th>Sections</th></tr>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td class="small"><?= fmt_date($r['event_date']) ?></td>
        <td class="small"><?= h(explode(' · ', role_label($r['role']))[0]) ?></td>
        <td><a href="record.php?id=<?= (int)$r['record_id'] ?>"><span class="badge t-<?= h($r['record_type']) ?>"><?= record_type_label($r['record_type']) ?></span> <?= h($r['fir_number']) ?></a>
          <div class="small muted"><?= h($r['summary_en']) ?></div></td>
        <td><?= h($r['thana']) ?></td>
        <td class="small"><?= h($r['sections']) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
  <div class="card">
    <h2>Known details</h2>
    <dl class="kv">
      <dt>Name(s)</dt><dd><?= h(implode(', ', $names)) ?></dd>
      <dt>Father / husband</dt><dd><?= h($first['father_name']) ?: '—' ?> <span class="muted"><?= h($first['father_name_en']) ?></span></dd>
      <dt>Age</dt><dd><?= $ages ? h(implode(', ', array_unique($ages))) : '—' ?></dd>
      <dt>Phone</dt><dd><?= $phones ? h(implode(', ', $phones)) : '—' ?></dd>
      <dt>Address(es)</dt><dd><?= $addresses ? implode('<br>', array_map('h', $addresses)) : '—' ?></dd>
    </dl>
    <p class="hint">Matched on name + father's name across documents. An officer should confirm it is the same person before acting on it. Later this profile can open the Digital Criminal Dossier.</p>
  </div>
</div>
<?php page_foot();
