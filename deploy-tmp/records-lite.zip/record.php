<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
require __DIR__ . '/lib/search.php';
require_login();
$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare('SELECT r.*, d.filename, d.title doc_title, d.source, d.sender_name, d.received_at FROM records r JOIN documents d ON d.id=r.document_id WHERE r.id=?');
$st->execute([$id]);
$r = $st->fetch();
if (!$r) { http_response_code(404); exit('Record not found'); }
$ps = db()->prepare('SELECT * FROM persons WHERE record_id=? ORDER BY id');
$ps->execute([$id]);
$persons = $ps->fetchAll();
audit('view_record', "record $id");

// other appearances of the same people
$other = db()->prepare('SELECT COUNT(DISTINCT record_id) FROM persons WHERE person_key=? AND record_id<>?');

page_head(($r['fir_number'] ? 'FIR ' . $r['fir_number'] : record_type_label($r['record_type'])) . ' · ' . $r['thana']);
$vehicles = json_decode((string)$r['vehicle_numbers'], true) ?: [];
?>
<p><a href="javascript:history.back()">← Back</a></p>
<h1><span class="badge t-<?= h($r['record_type']) ?>"><?= record_type_label($r['record_type']) ?></span>
  <?= $r['fir_number'] ? 'FIR ' . h($r['fir_number']) . ' · ' : '' ?><?= h($r['thana']) ?></h1>
<div class="grid2">
  <div>
    <div class="card">
      <dl class="kv">
        <dt>District</dt><dd><?= h($r['district']) ?: '—' ?></dd>
        <dt>Thana</dt><dd><?= h($r['thana']) ?: '—' ?></dd>
        <?php if ($r['zone']): ?><dt>Zone</dt><dd><?= h($r['zone']) ?></dd><?php endif; ?>
        <?php if ($r['crime_head']): ?><dt>Crime</dt><dd><?= h($r['crime_head']) ?> <span class="muted">(<?= h($r['crime_head_en']) ?>)</span></dd><?php endif; ?>
        <dt>Sections / Act</dt><dd><?= h($r['sections']) ?: '—' ?></dd>
        <?php if ($r['record_type'] === 'fir'): ?>
          <dt>Report date</dt><dd><?= fmt_date($r['report_datetime']) ?></dd>
          <dt>Incident date</dt><dd><?= fmt_date($r['incident_datetime']) ?></dd>
          <dt>Incident place</dt><dd><?= h($r['incident_place']) ?: '—' ?></dd>
        <?php else: ?>
          <dt>Release date</dt><dd><?= fmt_date($r['release_date']) ?></dd>
          <dt>In jail since</dt><dd><?= fmt_date($r['jail_entry_date']) ?></dd>
        <?php endif; ?>
        <?php if ($r['property_loss']): ?><dt>Property / loss</dt><dd><?= h($r['property_loss']) ?></dd><?php endif; ?>
        <?php if ($vehicles): ?><dt>Vehicles</dt><dd><?= h(implode(', ', $vehicles)) ?></dd><?php endif; ?>
      </dl>
    </div>
    <?php if ($r['details'] || $r['summary_en']): ?>
    <div class="card"><h2>Details · विवरण</h2>
      <p class="details"><?= nl2br(h($r['details'])) ?></p>
      <?php if ($r['summary_en']): ?><p class="muted small">English summary: <?= h($r['summary_en']) ?></p><?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
  <div>
    <div class="card"><h2>People</h2>
      <?php foreach ($persons as $p):
          $n = 0;
          if ($p['person_key']) { $other->execute([$p['person_key'], $id]); $n = (int)$other->fetchColumn(); } ?>
        <div class="person">
          <div class="small muted"><?= role_label($p['role']) ?></div>
          <div><?= person_line($p) ?></div>
          <?php if ($p['address']): ?><div class="small"><?= h($p['address']) ?></div><?php endif; ?>
          <?php if ($n): ?><div class="small"><a href="person.php?key=<?= urlencode($p['person_key']) ?>">⚑ Same name in <?= $n ?> other record<?= $n > 1 ? 's' : '' ?></a></div>
          <?php elseif ($p['person_key']): ?><div class="small"><a href="person.php?key=<?= urlencode($p['person_key']) ?>">Profile</a></div><?php endif; ?>
        </div>
      <?php endforeach; ?>
      <?php if (!$persons): ?><p class="muted">No named people in this row.</p><?php endif; ?>
    </div>
    <div class="card"><h2>Source</h2>
      <p class="small"><?= source_icon($r['source']) ?> <?= h($r['sender_name']) ?><br>
      <a href="document.php?id=<?= (int)$r['document_id'] ?>"><?= h($r['filename']) ?></a> · row <?= h($r['serial_no']) ?><br>
      <span class="muted">Received <?= fmt_date($r['received_at']) ?></span></p>
      <a class="btn sec sm" href="file.php?id=<?= (int)$r['document_id'] ?>" target="_blank">Open original PDF</a>
    </div>
  </div>
</div>
<?php page_foot();
