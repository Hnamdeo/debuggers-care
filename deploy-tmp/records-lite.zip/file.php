<?php
// Serves a stored PDF to signed-in users only.
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/ingest.php';
require_login();
$doc = get_document((int)($_GET['id'] ?? 0));
if (!$doc) { http_response_code(404); exit('Not found'); }
audit('view_pdf', "document {$doc['id']}");
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="' . rawurlencode($doc['filename']) . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile(APP_ROOT . '/' . $doc['stored_path']);
