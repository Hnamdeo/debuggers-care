<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$u = require_login();
if ($u['role'] !== 'admin') { http_response_code(403); exit('Admins only'); }
$rows = db()->query('SELECT * FROM audit_log ORDER BY id DESC LIMIT 500')->fetchAll();
page_head('Audit log', 'audit.php');
?>
<h1>Audit log</h1>
<p class="muted">Every sign-in, search, record view and PDF view is recorded with the officer's name.</p>
<div class="card tbl-wrap"><table>
<tr><th>When</th><th>User</th><th>Action</th><th>Detail</th><th>IP</th></tr>
<?php foreach ($rows as $r): ?>
<tr><td class="small"><?= fmt_date($r['at']) ?></td><td><?= h($r['username']) ?></td><td><?= h($r['action']) ?></td><td class="small"><?= h($r['detail']) ?></td><td class="small muted"><?= h($r['ip']) ?></td></tr>
<?php endforeach; ?>
</table></div>
<?php page_foot();
