<?php
// Loads the bundled synthetic sample PDFs as if they had arrived on WhatsApp.  php cli/seed_demo.php
declare(strict_types=1);
require __DIR__ . '/../lib/bootstrap.php';
require __DIR__ . '/../lib/ingest.php';
if (PHP_SAPI !== 'cli') { exit; }
$senders = [
    'dsr_city' => ['919000000101', 'DSR Cell, Raipur City'],
    'dsr_rural' => ['919000000102', 'DSR Cell, Raipur Rural'],
    'jail' => ['919000000103', 'Central Jail, Raipur'],
];
$man = json_decode((string)file_get_contents(APP_ROOT . '/samples/manifest.json'), true);
foreach ($man as $i => $m) {
    $tmp = tempnam(sys_get_temp_dir(), 'seed');
    copy(APP_ROOT . '/samples/pdfs/' . $m['filename'], $tmp);
    [$sender, $name] = $senders[$m['kind']];
    [$id, $dup] = store_document($tmp, $m['filename'], 'whatsapp', $sender, $name, 'demo-' . $i);
    if ($dup) { echo "skip {$m['filename']}\n"; continue; }
    $r = process_document($id);
    $at = $m['date'] . sprintf(' %02d:%02d:%02d', $m['kind'] === 'jail' ? 17 : 8, 10 + $i * 2 % 50, $i);
    db()->prepare('UPDATE documents SET received_at=?, processed_at=? WHERE id=?')->execute([$at, $at, $id]);
    echo "{$m['filename']}: ", $r['ok'] ? "{$r['records']} records" : $r['error'], PHP_EOL;
}
