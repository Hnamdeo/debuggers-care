<?php
// Cron fallback: php cli/process.php   (reads any document still pending or failed mid-way)
declare(strict_types=1);
require __DIR__ . '/../lib/bootstrap.php';
require __DIR__ . '/../lib/ingest.php';
if (PHP_SAPI !== 'cli') { exit; }
$ids = db()->query("SELECT id FROM documents WHERE status IN ('pending','processing') ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
foreach ($ids as $id) {
    $r = process_document((int)$id);
    echo $id, ': ', $r['ok'] ? "ok, {$r['records']} records" : 'error: ' . $r['error'], PHP_EOL;
}
