<?php
// Copy this file to config.php and fill in the values. Never commit config.php.
return [
    'app_name'      => 'Police Records Intelligence',
    'org_name'      => 'Crime Branch, Raipur',          // shown in the header
    'credit'        => 'Designed and developed by Debuggers Space Solutions',
    'demo_banner'   => true,                            // shows "Demo - synthetic data" banner

    // Database: SQLite (zero setup) or MySQL (Hostinger hPanel > Databases)
    'db' => [
        'driver' => 'sqlite',                           // 'sqlite' or 'mysql'
        'sqlite_path' => __DIR__ . '/storage/data.sqlite',
        'mysql' => ['host' => 'localhost', 'name' => '', 'user' => '', 'pass' => ''],
    ],

    // Users. Create hashes with:  php cli/hash.php "password"
    'users' => [
        // 'username' => ['name' => 'Display name', 'role' => 'admin|officer', 'hash' => '...'],
    ],

    // Claude API (AI reading of PDFs)
    'anthropic' => [
        'api_key' => '',                                // sk-ant-...
        'model'   => 'claude-opus-5-5',
        'effort'  => 'medium',
    ],

    // WhatsApp Business Cloud API (Meta)
    'whatsapp' => [
        'verify_token'    => '',                        // any random string, also entered in Meta app webhook settings
        'access_token'    => '',                        // permanent System User token
        'phone_number_id' => '',
        'app_secret'      => '',                        // used to verify X-Hub-Signature-256
        'graph_version'   => 'v23.0',
        'reply_to_sender' => true,                      // send "received, N records" acknowledgement
        // Only these senders are accepted (E.164 without +). Empty = accept all.
        'allowed_senders' => [
            // '919xxxxxxxxx' => 'Thana Kotwali',
        ],
    ],
];
