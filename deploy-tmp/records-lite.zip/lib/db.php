<?php
declare(strict_types=1);

function db(): PDO
{
    static $pdo = null;
    if ($pdo) {
        return $pdo;
    }
    if (cfg('db.driver') === 'mysql') {
        $m = cfg('db.mysql');
        $pdo = new PDO("mysql:host={$m['host']};dbname={$m['name']};charset=utf8mb4", $m['user'], $m['pass']);
    } else {
        $path = cfg('db.sqlite_path');
        $new = !is_file($path);
        $pdo = new PDO('sqlite:' . $path);
        $pdo->exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');
    }
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    migrate($pdo);
    return $pdo;
}

function migrate(PDO $pdo): void
{
    $mysql = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
    $id = $mysql ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $text = $mysql ? 'MEDIUMTEXT' : 'TEXT';
    $str = $mysql ? 'VARCHAR(255)' : 'TEXT';
    $tail = $mysql ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';

    $pdo->exec("CREATE TABLE IF NOT EXISTS documents (
        id $id,
        source $str NOT NULL,              -- whatsapp | upload | demo
        sender_phone $str NULL,
        sender_name $str NULL,
        wa_message_id $str NULL,
        filename $str NOT NULL,
        sha256 $str NOT NULL,
        stored_path $str NOT NULL,
        size_bytes INTEGER NULL,
        doc_type $str NULL,                -- daily_situation_report | jail_release_list | other
        title $str NULL,
        district $str NULL,
        report_date $str NULL,
        period_from $str NULL,
        period_to $str NULL,
        stated_count INTEGER NULL,
        record_count INTEGER NOT NULL DEFAULT 0,
        status $str NOT NULL DEFAULT 'pending',  -- pending | processing | done | review | error
        error $text NULL,
        ai_model $str NULL,
        ai_json $text NULL,
        received_at $str NOT NULL,
        processed_at $str NULL
    )$tail");

    $pdo->exec("CREATE TABLE IF NOT EXISTS records (
        id $id,
        document_id INTEGER NOT NULL,
        record_type $str NOT NULL,         -- fir | jail_release | other
        serial_no $str NULL,
        district $str NULL,
        thana $str NULL,
        zone $str NULL,
        fir_number $str NULL,
        crime_head $str NULL,
        crime_head_en $str NULL,
        sections $text NULL,
        report_datetime $str NULL,
        incident_datetime $str NULL,
        incident_place $text NULL,
        release_date $str NULL,
        jail_entry_date $str NULL,
        property_loss $text NULL,
        details $text NULL,
        summary_en $text NULL,
        vehicle_numbers $text NULL,
        phones $text NULL,
        event_date $str NULL,              -- best date for sorting / filtering
        search_text $text NULL,
        created_at $str NOT NULL
    )$tail");

    $pdo->exec("CREATE TABLE IF NOT EXISTS persons (
        id $id,
        record_id INTEGER NOT NULL,
        document_id INTEGER NOT NULL,
        role $str NOT NULL,
        name $str NULL,
        name_en $str NULL,
        father_name $str NULL,
        father_name_en $str NULL,
        age INTEGER NULL,
        gender $str NULL,
        address $text NULL,
        address_en $text NULL,
        phone $str NULL,
        person_key $str NULL
    )$tail");

    $pdo->exec("CREATE TABLE IF NOT EXISTS audit_log (
        id $id,
        at $str NOT NULL,
        username $str NULL,
        action $str NOT NULL,
        detail $text NULL,
        ip $str NULL
    )$tail");

    if ($mysql) {
        foreach (['CREATE INDEX ix_rec_doc ON records(document_id)', 'CREATE INDEX ix_per_rec ON persons(record_id)',
                  'CREATE INDEX ix_per_key ON persons(person_key)', 'CREATE UNIQUE INDEX ux_doc_sha ON documents(sha256)'] as $sql) {
            try { $pdo->exec($sql); } catch (PDOException) { /* already exists */ }
        }
    } else {
        $pdo->exec('CREATE INDEX IF NOT EXISTS ix_rec_doc ON records(document_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS ix_per_rec ON persons(record_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS ix_per_key ON persons(person_key)');
        $pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS ux_doc_sha ON documents(sha256)');
    }
}
