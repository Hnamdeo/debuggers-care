<?php
declare(strict_types=1);

const APP_ROOT = __DIR__ . '/..';
if (is_file(APP_ROOT . '/vendor/autoload.php')) {
    require_once APP_ROOT . '/vendor/autoload.php';
}

$cfgFile = APP_ROOT . '/config.php';
if (!is_file($cfgFile)) {
    $cfgFile = APP_ROOT . '/config.sample.php';
}
$GLOBALS['CFG'] = require $cfgFile;

function cfg(string $path, mixed $default = null): mixed
{
    $v = $GLOBALS['CFG'];
    foreach (explode('.', $path) as $k) {
        if (!is_array($v) || !array_key_exists($k, $v)) {
            return $default;
        }
        $v = $v[$k];
    }
    return $v;
}

date_default_timezone_set('Asia/Kolkata');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';
