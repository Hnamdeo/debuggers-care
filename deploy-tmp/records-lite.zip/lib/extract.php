<?php
declare(strict_types=1);

use Anthropic\Client;
use Anthropic\Messages\RawContentBlockDeltaEvent;
use Anthropic\Messages\RawMessageDeltaEvent;
use Anthropic\Messages\TextDelta;

/** JSON schema the AI must fill for every police document. */
function extraction_schema(): array
{
    $s = ['type' => ['string', 'null']];
    $i = ['type' => ['integer', 'null']];
    $person = [
        'type' => 'object',
        'additionalProperties' => false,
        'required' => ['role', 'name', 'name_en', 'father_name', 'father_name_en', 'age', 'gender', 'address', 'address_en', 'phone'],
        'properties' => [
            'role' => ['type' => 'string', 'enum' => ['accused', 'victim', 'complainant', 'released_prisoner', 'deceased', 'other']],
            'name' => $s, 'name_en' => $s, 'father_name' => $s, 'father_name_en' => $s,
            'age' => $i, 'gender' => ['type' => ['string', 'null'], 'enum' => ['M', 'F', null]],
            'address' => $s, 'address_en' => $s, 'phone' => $s,
        ],
    ];
    $record = [
        'type' => 'object',
        'additionalProperties' => false,
        'required' => ['serial_no', 'record_type', 'district', 'thana', 'zone', 'fir_number', 'crime_head', 'crime_head_en',
            'sections', 'report_datetime', 'incident_datetime', 'incident_place', 'release_date', 'jail_entry_date',
            'property_loss', 'details', 'summary_en', 'vehicle_numbers', 'phones', 'persons'],
        'properties' => [
            'serial_no' => $s,
            'record_type' => ['type' => 'string', 'enum' => ['fir', 'jail_release', 'other']],
            'district' => $s, 'thana' => $s, 'zone' => $s,
            'fir_number' => $s, 'crime_head' => $s, 'crime_head_en' => $s, 'sections' => $s,
            'report_datetime' => $s, 'incident_datetime' => $s, 'incident_place' => $s,
            'release_date' => $s, 'jail_entry_date' => $s,
            'property_loss' => $s, 'details' => $s, 'summary_en' => $s,
            'vehicle_numbers' => ['type' => 'array', 'items' => ['type' => 'string']],
            'phones' => ['type' => 'array', 'items' => ['type' => 'string']],
            'persons' => ['type' => 'array', 'items' => $person],
        ],
    ];
    return [
        'type' => 'object',
        'additionalProperties' => false,
        'required' => ['document_type', 'title', 'district', 'report_date', 'period_from', 'period_to', 'stated_count', 'records', 'reader_notes'],
        'properties' => [
            'document_type' => ['type' => 'string', 'enum' => ['daily_situation_report', 'jail_release_list', 'other']],
            'title' => $s, 'district' => $s, 'report_date' => $s, 'period_from' => $s, 'period_to' => $s,
            'stated_count' => $i,
            'records' => ['type' => 'array', 'items' => $record],
            'reader_notes' => $s,
        ],
    ];
}

function extraction_prompt(): string
{
    return <<<TXT
You read police documents from Chhattisgarh Police (Raipur) and turn every row into structured data for a records database.

Documents you will see:
- Daily Situation Report (DSR, "प्रकरणों की सूची"): one row per FIR. Columns: थाना {जिला}, अपराध क्र. / रिपोर्ट दिनांक, धारा, घटना दिनांक / घटना स्थल / आवेदक, आरोपी, पीड़ित / सम्पत्ति क्षति, विवरण.
- Jail Rihai list ("जेल रिहाई"): one row per released prisoner. Columns: क्र., रिहाई दिनांक, नाम आरोपी पता, थाना, धारा, जेल निरुद्ध दिनांक, जोन.
- Anything else: use document_type "other" and capture every named person you can find.

Rules:
- One entry in "records" for every numbered row. Never skip, merge or invent rows. stated_count = the count printed on the document (e.g. "( 28 प्रकरण)"), else null.
- Copy Hindi text exactly as printed, in Unicode Devanagari. Fill the *_en fields with a plain English transliteration (e.g. "अनीश ताण्डी" -> "Anish Tandi") so officers can search in English.
- fir_number like "438/26". sections exactly as printed, e.g. "बीएनएस: 64-2", "25,27 आर्म्स एक्ट". crime_head is the crime type under the FIR number (e.g. अपहरण, नकबजनी, बलात्कार); crime_head_en its English meaning (Kidnapping, House-breaking, Rape...).
- Dates as YYYY-MM-DD and date-times as YYYY-MM-DD HH:MM. Two-digit years are 20xx.
- Persons: list every accused, victim, complainant (आवेदक), deceased, and for jail lists the released prisoner. In DSRs "(F)" or "(H)" before a name marks father (F) or husband (H); put that name in father_name. "#- {31 पु}" means age 31, male (पु = M, म = F). "+ 1 अज्ञात" means an unknown accused: add one accused with name "अज्ञात" and name_en "Unknown". A complainant that is "शासन" (the State) is not a person: skip it.
- In jail lists, "नाम आरोपी पता" holds name, father (पिता), age (उम्र .. साल) and address (निवासी ...): split them.
- vehicle_numbers: every vehicle registration in the row, normalised like "CG 04 PR 0302". phones: every phone number in the row.
- summary_en: one short English sentence of what happened.
- Use null when a value is not on the document. Do not guess.
- reader_notes: anything unclear (unreadable cells, possible misreads), else null.
TXT;
}

/**
 * Send a PDF to Claude and return the decoded extraction array.
 * @throws RuntimeException
 */
function ai_extract_pdf(string $pdfPath): array
{
    $key = (string)cfg('anthropic.api_key');
    if ($key === '') {
        throw new RuntimeException('AI reader is not configured (no Anthropic API key).');
    }
    if (!class_exists(Client::class)) {
        throw new RuntimeException('AI library missing: upload the vendor/ folder (composer install).');
    }
    $client = new Client(apiKey: $key, baseUrl: 'https://api.anthropic.com');

    $stream = $client->messages->createStream(
        model: (string)cfg('anthropic.model', 'claude-opus-5-5'),
        maxTokens: 64000,
        system: extraction_prompt(),
        outputConfig: [
            'effort' => (string)cfg('anthropic.effort', 'medium'),
            'format' => ['type' => 'json_schema', 'schema' => extraction_schema()],
        ],
        messages: [[
            'role' => 'user',
            'content' => [
                ['type' => 'document', 'source' => ['type' => 'base64', 'mediaType' => 'application/pdf', 'data' => base64_encode((string)file_get_contents($pdfPath))]],
                ['type' => 'text', 'text' => 'Extract every record from this document.'],
            ],
        ]],
    );

    $text = '';
    $stop = null;
    foreach ($stream as $event) {
        if ($event instanceof RawContentBlockDeltaEvent && $event->delta instanceof TextDelta) {
            $text .= $event->delta->text;
        } elseif ($event instanceof RawMessageDeltaEvent) {
            $stop = $event->delta->stopReason ?? $stop;
        }
    }
    if ($stop === 'refusal') {
        throw new RuntimeException('The AI declined to read this document. Please review it by hand.');
    }
    if ($stop === 'max_tokens') {
        throw new RuntimeException('Document too long for one pass. Split the PDF and send again.');
    }
    $data = json_decode($text, true);
    if (!is_array($data)) {
        throw new RuntimeException('AI reply was not valid JSON.');
    }
    return $data;
}
