<?php
declare(strict_types=1);

/** Highlight query tokens in an escaped string. */
function hl(?string $text, array $tokens): string
{
    $out = h($text);
    foreach ($tokens as $t) {
        if (mb_strlen($t) < 2) {
            continue;
        }
        $out = preg_replace('/(' . preg_quote(h($t), '/') . ')/iu', '<mark>$1</mark>', $out);
    }
    return $out;
}

function query_tokens(string $q): array
{
    $q = mb_strtolower(trim($q));
    if ($q === '') {
        return [];
    }
    // quoted phrases stay together
    preg_match_all('/"([^"]+)"|(\S+)/u', $q, $m, PREG_SET_ORDER);
    $t = [];
    foreach ($m as $x) {
        $t[] = $x[1] !== '' ? $x[1] : $x[2];
    }
    return $t;
}

/** Search records with filters. Returns rows with their persons attached. */
function search_records(array $f, int $limit = 200): array
{
    $where = ['1=1'];
    $args = [];
    foreach (query_tokens((string)($f['q'] ?? '')) as $tok) {
        $alts = ['r.search_text LIKE ?'];
        $args[] = '%' . $tok . '%';
        $digits = preg_replace('/\D/', '', $tok);
        if (strlen($digits) >= 6 && $digits !== $tok) { // phone typed with spaces/dashes
            $alts[] = 'r.search_text LIKE ?';
            $args[] = '%' . $digits . '%';
        }
        $where[] = '(' . implode(' OR ', $alts) . ')';
    }
    foreach (['type' => 'r.record_type', 'thana' => 'r.thana', 'district' => 'r.district'] as $k => $col) {
        if (!empty($f[$k])) {
            $where[] = "$col = ?";
            $args[] = $f[$k];
        }
    }
    if (!empty($f['section'])) {
        $where[] = 'r.sections LIKE ?';
        $args[] = '%' . $f['section'] . '%';
    }
    if (!empty($f['from'])) {
        $where[] = 'r.event_date >= ?';
        $args[] = $f['from'];
    }
    if (!empty($f['to'])) {
        $where[] = 'r.event_date <= ?';
        $args[] = $f['to'];
    }
    $sql = 'SELECT r.*, d.filename, d.doc_type, d.source FROM records r JOIN documents d ON d.id = r.document_id WHERE '
        . implode(' AND ', $where) . ' ORDER BY r.event_date DESC, r.id DESC LIMIT ' . (int)$limit;
    $st = db()->prepare($sql);
    $st->execute($args);
    $rows = $st->fetchAll();
    if (!$rows) {
        return [];
    }
    $ids = array_column($rows, 'id');
    $ps = db()->query('SELECT * FROM persons WHERE record_id IN (' . implode(',', array_map('intval', $ids)) . ') ORDER BY id')->fetchAll();
    $by = [];
    foreach ($ps as $p) {
        $by[$p['record_id']][] = $p;
    }
    foreach ($rows as &$r) {
        $r['persons'] = $by[$r['id']] ?? [];
    }
    return $rows;
}

/** People whose name/father/phone match, grouped across documents. */
function search_people(string $q, int $limit = 24): array
{
    $toks = query_tokens($q);
    if (!$toks) {
        return [];
    }
    $where = [];
    $args = [];
    foreach ($toks as $t) {
        $where[] = '(LOWER(COALESCE(p.name,\'\')||\' \'||COALESCE(p.name_en,\'\')||\' \'||COALESCE(p.father_name,\'\')||\' \'||COALESCE(p.father_name_en,\'\')||\' \'||COALESCE(p.phone,\'\')) LIKE ?)';
        $args[] = '%' . $t . '%';
    }
    $sql = 'SELECT p.person_key, MIN(p.name) name, MIN(p.name_en) name_en, MIN(p.father_name) father_name, MAX(p.age) age,
            COUNT(DISTINCT p.record_id) n, GROUP_CONCAT(DISTINCT p.role) roles, MIN(p.id) any_id
            FROM persons p WHERE p.person_key IS NOT NULL AND ' . implode(' AND ', $where) . '
            GROUP BY p.person_key ORDER BY n DESC, name LIMIT ' . (int)$limit;
    if (db()->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql') {
        $sql = str_replace("||' '||", ", ' ', ", $sql);
        $sql = preg_replace('/LOWER\((COALESCE.*?)\) LIKE/', 'LOWER(CONCAT($1)) LIKE', $sql);
    }
    $st = db()->prepare($sql);
    $st->execute($args);
    return $st->fetchAll();
}

function distinct_values(string $col): array
{
    $col = preg_replace('/[^a-z_]/', '', $col);
    return db()->query("SELECT DISTINCT $col FROM records WHERE $col IS NOT NULL AND $col <> '' ORDER BY $col")->fetchAll(PDO::FETCH_COLUMN);
}

function person_line(array $p, array $tokens = []): string
{
    $s = '<b>' . hl($p['name'] ?: $p['name_en'], $tokens) . '</b>';
    if ($p['name_en'] && $p['name']) {
        $s .= ' <span class="muted small">(' . hl($p['name_en'], $tokens) . ')</span>';
    }
    if ($p['father_name']) {
        $s .= ' <span class="small">c/o ' . hl($p['father_name'], $tokens) . '</span>';
    }
    if ($p['age']) {
        $s .= ' <span class="muted small">· ' . (int)$p['age'] . ' yrs' . ($p['gender'] ? ', ' . $p['gender'] : '') . '</span>';
    }
    if ($p['phone']) {
        $s .= ' <span class="small">· ☎ ' . hl($p['phone'], $tokens) . '</span>';
    }
    return $s;
}
