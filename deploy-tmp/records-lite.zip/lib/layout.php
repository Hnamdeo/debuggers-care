<?php
declare(strict_types=1);

function page_head(string $title, string $active = ''): void
{
    $u = current_user();
    $app = h(cfg('app_name'));
    $org = h(cfg('org_name'));
    $nav = ['index.php' => 'Search', 'documents.php' => 'Documents', 'people.php' => 'Repeat names'];
    if (($u['role'] ?? '') === 'admin') {
        $nav['audit.php'] = 'Audit log';
    }
    ?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= h($title) ?> · <?= $app ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Noto+Sans+Devanagari:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/app.css?v=3">
</head>
<body>
<?php if (cfg('demo_banner')): ?><div class="demo-banner">Demo build for evaluation · all names and cases shown are synthetic</div><?php endif; ?>
<header class="top">
  <div class="brand">
    <svg viewBox="0 0 32 36" class="shield" aria-hidden="true"><path d="M16 1 30 6v11c0 9-6 15-14 18C8 32 2 26 2 17V6z" fill="currentColor"/><path d="M10 18l4 4 8-9" stroke="#0f2a4a" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
    <div><div class="app"><?= $app ?></div><div class="org"><?= $org ?></div></div>
  </div>
  <?php if ($u): ?>
  <nav><?php foreach ($nav as $href => $label): ?><a href="<?= $href ?>" class="<?= $active === $href ? 'on' : '' ?>"><?= $label ?></a><?php endforeach; ?></nav>
  <div class="who"><?= h($u['name']) ?> · <a href="logout.php">Sign out</a></div>
  <?php endif; ?>
</header>
<main>
<?php
}

function page_foot(): void
{
    ?>
</main>
<footer class="foot"><?= h(cfg('credit')) ?> · Confidential · Access is logged</footer>
</body>
</html>
<?php
}

function status_badge(string $s): string
{
    $label = ['pending' => 'Waiting', 'processing' => 'Reading…', 'done' => 'Saved', 'review' => 'Check', 'error' => 'Failed'][$s] ?? $s;
    return '<span class="badge st-' . h($s) . '">' . $label . '</span>';
}

function source_icon(string $src): string
{
    return match ($src) {
        'whatsapp' => '<span class="src wa" title="Received on WhatsApp">WhatsApp</span>',
        'upload' => '<span class="src up" title="Uploaded on dashboard">Upload</span>',
        default => '<span class="src dm">Demo</span>',
    };
}
