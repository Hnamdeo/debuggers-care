<?php
declare(strict_types=1);

/** Minimal WhatsApp Business Cloud API helpers (Meta Graph API). */

function wa_graph(string $path): string
{
    return 'https://graph.facebook.com/' . cfg('whatsapp.graph_version', 'v23.0') . '/' . ltrim($path, '/');
}

function wa_http(string $method, string $url, ?array $json = null, bool $raw = false): array
{
    $ch = curl_init($url);
    $headers = ['Authorization: Bearer ' . cfg('whatsapp.access_token')];
    if ($json !== null) {
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($json, JSON_UNESCAPED_UNICODE));
    }
    curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_HTTPHEADER => $headers, CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 60, CURLOPT_FOLLOWLOCATION => true]);
    $body = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 300) {
        throw new RuntimeException("WhatsApp API $code: " . substr($body, 0, 300));
    }
    return $raw ? ['body' => $body] : (json_decode($body, true) ?: []);
}

/** Download a media file sent to the business number into a temp file. */
function wa_download_media(string $mediaId): string
{
    $meta = wa_http('GET', wa_graph($mediaId));
    if (empty($meta['url'])) {
        throw new RuntimeException('WhatsApp did not return a media URL');
    }
    $bytes = wa_http('GET', $meta['url'], null, true)['body'];
    $tmp = tempnam(sys_get_temp_dir(), 'wa');
    file_put_contents($tmp, $bytes);
    return $tmp;
}

function wa_send_text(string $to, string $text): void
{
    try {
        wa_http('POST', wa_graph(cfg('whatsapp.phone_number_id') . '/messages'), [
            'messaging_product' => 'whatsapp', 'to' => $to, 'type' => 'text', 'text' => ['body' => $text],
        ]);
    } catch (Throwable $e) {
        error_log('WhatsApp reply failed: ' . $e->getMessage());
    }
}

function wa_signature_ok(string $rawBody): bool
{
    $secret = (string)cfg('whatsapp.app_secret');
    if ($secret === '') {
        return true; // not configured (demo); configure in production
    }
    $sig = $_SERVER['HTTP_X_HUB_SIGNATURE_256'] ?? '';
    return hash_equals('sha256=' . hash_hmac('sha256', $rawBody, $secret), $sig);
}
