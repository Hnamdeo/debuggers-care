<?php
declare(strict_types=1);

require_once __DIR__ . '/extract.php';

/** Save an incoming PDF and create a pending document row. Returns [id, isDuplicate]. */
function store_document(string $tmpPath, string $origName, string $source, ?string $senderPhone = null, ?string $senderName = null, ?string $waMessageId = null): array
{
    $sha = hash_file('sha256', $tmpPath);
    $st = db()->prepare('SELECT id FROM documents WHERE sha256 = ?');
    $st->execute([$sha]);
    if ($id = $st->fetchColumn()) {
        return [(int)$id, true];
    }
    $dir = APP_ROOT . '/storage/pdfs/' . date('Y/m');
    if (!is_dir($dir)) {
        mkdir($dir, 0750, true);
    }
    $dest = $dir . '/' . substr($sha, 0, 16) . '.pdf';
    if (!@rename($tmpPath, $dest)) {
        copy($tmpPath, $dest);
    }
    $clean = preg_replace('/[^\p{L}\p{N} ._()-]/u', '_', $origName) ?: 'document.pdf';
    db()->prepare('INSERT INTO documents (source, sender_phone, sender_name, wa_message_id, filename, sha256, stored_path, size_bytes, status, received_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?)')
        ->execute([$source, $senderPhone, $senderName, $waMessageId, $clean, $sha, substr($dest, strlen(APP_ROOT) + 1), filesize($dest), 'pending', now()]);
    return [(int)db()->lastInsertId(), false];
}

/** Read a stored document with the AI (or a saved demo reading) and write its records. */
function process_document(int $id): array
{
    $doc = get_document($id);
    if (!$doc) {
        throw new RuntimeException("Document $id not found");
    }
    db()->prepare("UPDATE documents SET status='processing', error=NULL WHERE id=?")->execute([$id]);
    try {
        $replay = APP_ROOT . '/samples/readings/' . $doc['sha256'] . '.json';
        if (is_file($replay) && (string)cfg('anthropic.api_key') === '') {
            $data = json_decode((string)file_get_contents($replay), true);
            $model = 'saved demo reading';
        } else {
            $data = ai_extract_pdf(APP_ROOT . '/' . $doc['stored_path']);
            $model = (string)cfg('anthropic.model');
        }
        $n = save_extraction($id, $data, $model);
        return ['ok' => true, 'records' => $n, 'doc' => get_document($id)];
    } catch (Throwable $e) {
        db()->prepare("UPDATE documents SET status='error', error=?, processed_at=? WHERE id=?")->execute([$e->getMessage(), now(), $id]);
        return ['ok' => false, 'error' => $e->getMessage(), 'doc' => get_document($id)];
    }
}

function get_document(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM documents WHERE id=?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function save_extraction(int $docId, array $data, string $model): int
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $pdo->prepare('DELETE FROM persons WHERE document_id=?')->execute([$docId]);
        $pdo->prepare('DELETE FROM records WHERE document_id=?')->execute([$docId]);

        $recSt = $pdo->prepare('INSERT INTO records (document_id, record_type, serial_no, district, thana, zone, fir_number, crime_head, crime_head_en, sections,
            report_datetime, incident_datetime, incident_place, release_date, jail_entry_date, property_loss, details, summary_en, vehicle_numbers, phones,
            event_date, search_text, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $perSt = $pdo->prepare('INSERT INTO persons (record_id, document_id, role, name, name_en, father_name, father_name_en, age, gender, address, address_en, phone, person_key)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');

        $records = $data['records'] ?? [];
        foreach ($records as $r) {
            $district = $r['district'] ?: ($data['district'] ?? null);
            $report = norm_date($r['report_datetime'] ?? null, true);
            $incident = norm_date($r['incident_datetime'] ?? null, true);
            $release = norm_date($r['release_date'] ?? null);
            $jail = norm_date($r['jail_entry_date'] ?? null);
            $event = $release ?: ($report ? substr($report, 0, 10) : null) ?: norm_date($data['report_date'] ?? null);
            $vehicles = array_values(array_filter($r['vehicle_numbers'] ?? []));
            $phones = array_values(array_filter($r['phones'] ?? []));
            $people = $r['persons'] ?? [];

            $search = [$district, $r['thana'], $r['zone'], $r['fir_number'], $r['crime_head'], $r['crime_head_en'], $r['sections'],
                $r['incident_place'], $r['property_loss'], $r['details'], $r['summary_en'], implode(' ', $vehicles),
                str_replace(' ', '', implode(' ', $vehicles)), implode(' ', $phones)];
            foreach ($people as $p) {
                array_push($search, $p['name'], $p['name_en'], $p['father_name'], $p['father_name_en'], $p['address'], $p['address_en'], $p['phone']);
            }
            $recSt->execute([$docId, 'fir' === $r['record_type'] || 'jail_release' === $r['record_type'] ? $r['record_type'] : 'other',
                $r['serial_no'], $district, $r['thana'], $r['zone'], $r['fir_number'], $r['crime_head'], $r['crime_head_en'], $r['sections'],
                $report, $incident, $r['incident_place'], $release, $jail, $r['property_loss'], $r['details'], $r['summary_en'],
                json_encode($vehicles, JSON_UNESCAPED_UNICODE), json_encode($phones), $event,
                mb_strtolower(implode(' | ', array_filter($search, fn($v) => $v !== null && $v !== ''))), now()]);
            $recId = (int)$pdo->lastInsertId();

            foreach ($people as $p) {
                $perSt->execute([$recId, $docId, $p['role'], $p['name'], $p['name_en'], $p['father_name'], $p['father_name_en'],
                    $p['age'], $p['gender'], $p['address'], $p['address_en'], $p['phone'],
                    $p['name_en'] && strtolower($p['name_en']) !== 'unknown' ? person_key($p['name_en'], $p['father_name_en']) : null]);
            }
        }

        $count = count($records);
        $stated = $data['stated_count'] ?? null;
        $status = ($stated !== null && (int)$stated !== $count) || !empty($data['reader_notes']) ? 'review' : 'done';
        $pdo->prepare('UPDATE documents SET doc_type=?, title=?, district=?, report_date=?, period_from=?, period_to=?, stated_count=?, record_count=?,
            status=?, error=?, ai_model=?, ai_json=?, processed_at=? WHERE id=?')
            ->execute([$data['document_type'] ?? 'other', $data['title'] ?? null, $data['district'] ?? null, norm_date($data['report_date'] ?? null),
                norm_date($data['period_from'] ?? null, true), norm_date($data['period_to'] ?? null, true), $stated, $count, $status,
                $status === 'review' ? trim(($stated !== null && (int)$stated !== $count ? "Document says $stated, AI found $count. " : '') . ($data['reader_notes'] ?? '')) : null,
                $model, json_encode($data, JSON_UNESCAPED_UNICODE), now(), $docId]);
        $pdo->commit();
        return $count;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}
