<?php
declare(strict_types=1);

function h(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

function start_session(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
        session_name('prisid');
        session_start();
    }
}

function current_user(): ?array
{
    start_session();
    return $_SESSION['user'] ?? null;
}

function require_login(): array
{
    $u = current_user();
    if (!$u) {
        header('Location: login.php?next=' . urlencode($_SERVER['REQUEST_URI'] ?? 'index.php'));
        exit;
    }
    return $u;
}

function csrf_token(): string
{
    start_session();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function check_csrf(): void
{
    if (!hash_equals(csrf_token(), (string)($_POST['csrf'] ?? ''))) {
        http_response_code(400);
        exit('Invalid form token. Please reload the page.');
    }
}

function audit(string $action, ?string $detail = null): void
{
    $u = current_user();
    db()->prepare('INSERT INTO audit_log (at, username, action, detail, ip) VALUES (?,?,?,?,?)')
        ->execute([now(), $u['username'] ?? 'system', $action, $detail, $_SERVER['REMOTE_ADDR'] ?? 'cli']);
}

/** Normalise a name for matching the same person across documents. */
function person_key(?string $nameEn, ?string $fatherEn): ?string
{
    $n = norm_latin($nameEn);
    if ($n === '') {
        return null;
    }
    return $n . '|' . norm_latin($fatherEn);
}

function norm_latin(?string $s): string
{
    $s = strtolower((string)$s);
    $s = preg_replace('/\b(late|lt|sri|shri|smt|kumari|mr|mrs|ms|urf|alias)\b\.?/', ' ', $s);
    $s = preg_replace('/[^a-z ]/', '', $s);
    // simple phonetic folding for common Hindi transliteration variants
    $s = strtr($s, ['aa' => 'a', 'ee' => 'i', 'oo' => 'u', 'w' => 'v', 'sh' => 's', 'ph' => 'f', 'z' => 'j']);
    $s = preg_replace('/(.)\1+/', '$1', $s);
    return trim(preg_replace('/\s+/', ' ', $s));
}

/** Parse many date shapes to Y-m-d (or Y-m-d H:i), else null. */
function norm_date(?string $s, bool $withTime = false): ?string
{
    $s = trim((string)$s);
    if ($s === '') {
        return null;
    }
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/', $s, $m)) {
        return $withTime && isset($m[4]) ? "$m[1]-$m[2]-$m[3] $m[4]:$m[5]" : "$m[1]-$m[2]-$m[3]";
    }
    if (preg_match('/^(\d{1,2})[-.\/](\d{1,2})[-.\/](\d{2,4})(?:\s+(\d{1,2}):(\d{2}))?/', $s, $m)) {
        $y = strlen($m[3]) === 2 ? '20' . $m[3] : $m[3];
        $d = sprintf('%04d-%02d-%02d', $y, $m[2], $m[1]);
        return $withTime && isset($m[4]) ? $d . sprintf(' %02d:%02d', $m[4], $m[5]) : $d;
    }
    return null;
}

function fmt_date(?string $s): string
{
    if (!$s) {
        return '—';
    }
    $t = strtotime($s);
    if (!$t) {
        return h($s);
    }
    return strlen($s) > 10 ? date('d M Y, H:i', $t) : date('d M Y', $t);
}

function doc_type_label(?string $t): string
{
    return match ($t) {
        'daily_situation_report' => 'Daily Situation Report',
        'jail_release_list' => 'Jail Release (रिहाई) List',
        'other' => 'Other document',
        default => 'Not read yet',
    };
}

function record_type_label(string $t): string
{
    return match ($t) {
        'fir' => 'FIR',
        'jail_release' => 'Jail release',
        default => 'Record',
    };
}

function role_label(string $r): string
{
    return match ($r) {
        'accused' => 'Accused · आरोपी',
        'victim' => 'Victim · पीड़ित',
        'complainant' => 'Complainant · आवेदक',
        'released_prisoner' => 'Released · रिहा',
        'deceased' => 'Deceased · मृतक',
        default => 'Other',
    };
}

function mask_phone(?string $p): string
{
    return $p ? h($p) : '';
}
